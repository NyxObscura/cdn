// main.js

// Impor modul-modul yang diperlukan
require("./config");
const {
    useMultiFileAuthState,
    DisconnectReason,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    makeCacheableSignalKeyStore,
    makeInMemoryStore,
    jidDecode,
    fetchLatestBaileysVersion,
    proto,
    Browsers
} = require("@adiwajshing/baileys");
const NodeCache = require("node-cache");
const pino = require("pino");
const ws = require("ws");
const path = require("path");
const fs = require("fs");
const os = require("os");
const yargs = require("yargs/yargs");
const {
    spawn
} = require("child_process");
const _ = require("lodash");
const syntaxError = require("syntax-error");
const chalk = require("chalk");
let simple = require("./lib/simple");

// Impor LowDB untuk database JSON
let Low, JSONFile;
try {
    Low = require("lowdb").Low;
    JSONFile = require("lowdb").JSONFile;
} catch {
    Low = require("./lib/lowdb").Low;
    JSONFile = require("./lib/lowdb").JSONFile;
}

const mongoDB = require("./lib/mongoDB");
const readline = require("readline");

// Fungsi untuk menanyakan input dari pengguna di terminal
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

// --- Pengaturan Global ---
global.API = (name, path = "/", query = {}, apikey) => (name in global.APIs ? global.APIs[name] : name) + path + (query || apikey ? "?" + new URLSearchParams(Object.entries({
    ...query,
    ...(apikey ? {
        [apikey]: global.APIKeys[name in global.APIs ? global.APIs[name] : name]
    } : {})
})) : '');

global.timestamp = {
    start: new Date()
};
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());
global.prefix = new RegExp("^[" + (opts.prefix || "‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-").replace(/[|\\{}()[\]^$+*?.\-\^]/g, "\\$&") + "]");

// Inisialisasi Database
const dbAdapter = /https?:\/\//.test(opts.db || '') ? new cloudDBAdapter(opts.db) : /mongodb/.test(opts.db) ? new mongoDB(opts.db) : new JSONFile((opts._[0] ? opts._[0] + "_" : '') + "database.json");
global.db = new Low(dbAdapter);
global.DATABASE = global.db;

// Fungsi untuk memuat database
global.loadDatabase = async function loadDatabase() {
    if (global.db.READ) {
        return new Promise((resolve) => setInterval(function() {
            if (!global.db.READ) {
                clearInterval(this);
                resolve(global.db.data == null ? global.loadDatabase() : global.db.data);
            }
        }, 1000));
    }
    if (global.db.data !== null) return;

    global.db.READ = true;
    await global.db.read();
    global.db.READ = false;
    global.db.data = {
        users: {},
        chats: {},
        stats: {},
        msgs: {},
        sticker: {},
        ...(global.db.data || {})
    };
    global.db.chain = _.chain(global.db.data);
};
loadDatabase();

// --- Fungsi Utama Bot ---

async function startBot() {
    // Fungsi untuk mendapatkan informasi browser
    const getBrowserInfo = (browserName = "Chrome") => {
        const platform = os.platform();
        const osName = platform === "win32" ? "Windows" : platform === "darwin" ? "MacOS" : "Linux";
        const browserVersion = osName === "Linux" ? Browsers.ubuntu(browserName)[2] : "N/A";
        return [osName, browserName, browserVersion];
    };

    const sessionName = '' + (opts._[0] || "sessions");
    global.isInit = !fs.existsSync(sessionName);

    // Otentikasi dan State
    const {
        state,
        saveCreds
    } = await useMultiFileAuthState(sessionName);
    const {
        version,
        isLatest
    } = await fetchLatestBaileysVersion();
    console.log(chalk.magenta(`-- Menggunakan WA v${version.join(".")}, Versi Terbaru: ${isLatest} --`));

    const msgRetryCounterCache = new NodeCache();

    // Opsi koneksi Baileys
    const socketConfig = {
        printQRInTerminal: false,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (message) => {
            const isButtonMessage = !!(message.buttonsMessage || message.templateMessage || message.listMessage);
            if (isButtonMessage) {
                message = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {}
                            },
                            ...message
                        }
                    }
                };
            }
            return message;
        },
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino().child({
                level: "silent",
                stream: "store"
            }))
        },
        msgRetryCounterCache,
        browser: getBrowserInfo(),
        logger: pino({
            level: "silent"
        }),
        version
    };

    global.conn = simple.makeWASocket(socketConfig);

    // Menulis database secara berkala
    if (!opts.test && global.db) {
        setInterval(async () => {
            if (global.db.data) await global.db.write();
            if (!opts.tmp && (global.support || {}).find) {
                const tmpDirs = [os.tmpdir(), "tmp"];
                tmpDirs.forEach(dir => spawn("find", [dir, "-amin", "3", "-type", "f", "-delete"]));
            }
        }, 30 * 1000);
    }

    // Handler untuk update koneksi
    async function handleConnectionUpdate(update) {
        const {
            connection,
            lastDisconnect
        } = update;
        global.timestamp.connect = new Date();
        if (lastDisconnect && lastDisconnect.error && lastDisconnect.error.output && lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut && conn.ws.readyState !== ws.CONNECTING) {
            console.log(global.reloadHandler(true));
        }
        if (global.db.data == null) {
            await loadDatabase();
        }
    }

    // Logika pairing code jika belum terdaftar
    if (fs.existsSync("./sessions/creds.json") && !conn.authState.creds.registered) {
        console.log(chalk.yellow("-- PERINGATAN: file creds.json rusak, harap hapus terlebih dahulu --"));
        process.exit(0);
    }

    if (!conn.authState.creds.registered) {
        let phoneNumber = '';
        do {
            phoneNumber = await question(chalk.blueBright("Masukkan nomor yang valid diawali dengan kode negara. Contoh: 62812xxxx:\n"));
            if (!/^\d+$/.test(phoneNumber) || phoneNumber.length < 10) {
                console.log(chalk.red("Nomor telepon tidak valid. Silakan masukkan nomor yang benar."));
            }
        } while (!/^\d+$/.test(phoneNumber) || phoneNumber.length < 10);

        rl.close();
        phoneNumber = phoneNumber.replace(/\D/g, '');
        console.log(chalk.bgWhite(chalk.blue("-- Harap tunggu, sedang membuat kode... --")));
        setTimeout(async () => {
            let code = await conn.requestPairingCode(phoneNumber);
            code = code?.match(/.{1,4}/g)?.join("-") || code;
            console.log(chalk.black(chalk.bgGreen("Kode Pairing Anda : ")), chalk.black(chalk.white(code)));
        }, 3000);
    }

    process.on("uncaughtException", console.error);

    // Fungsi untuk hot-reload modul
    const hotReload = (module) => {
        module = require.resolve(module);
        let M = require.cache[module];
        if (M) {
            delete require.cache[module];
        }
        return require(module);
    };

    // Handler utama untuk me-reload event listener
    let isFirstLoad = true;
    global.reloadHandler = function(isReconnect) {
        let handler = hotReload("./handler");
        if (isReconnect) {
            try {
                global.conn.ws.close();
            } catch {}
            global.conn = {
                ...global.conn,
                ...simple.makeWASocket(socketConfig)
            };
        }

        if (!isFirstLoad) {
            conn.ev.off("messages.upsert", conn.handler);
            conn.ev.off("group-participants.update", conn.participantsUpdate);
            conn.ev.off("message.delete", conn.onDelete);
            conn.ev.off("connection.update", conn.connectionUpdate);
            conn.ev.off("creds.update", conn.credsUpdate);
        }

        conn.welcome = "Selamat datang @user di grup @subject! Harap baca deskripsi ya.\n@desc";
        conn.bye = "Selamat tinggal @user 👋";
        conn.promote = "@user sekarang adalah admin!";
        conn.demote = "@user bukan lagi admin!";
        
        conn.handler = handler.handler.bind(conn);
        conn.participantsUpdate = handler.participantsUpdate.bind(conn);
        conn.onDelete = handler.delete.bind(conn);
        conn.connectionUpdate = handleConnectionUpdate.bind(conn);
        conn.credsUpdate = saveCreds.bind(conn);

        conn.ev.on("messages.upsert", conn.handler);
        conn.ev.on("group-participants.update", conn.participantsUpdate);
        conn.ev.on("message.delete", conn.onDelete);
        conn.ev.on("connection.update", conn.connectionUpdate);
        conn.ev.on("creds.update", conn.credsUpdate);
        
        // Menolak panggilan masuk
        conn.ev.on("call", async (call) => {
            console.log("Panggilan diterima:", call);
            if (call.status === "ringing") {
                await conn.rejectCall(call.id);
                console.log("Panggilan ditolak");
            }
        });

        isFirstLoad = false;
        return true;
    };


    // Memuat plugins
    const pluginsPath = path.join(__dirname, "plugins");
    const pluginFilter = filename => /\.js$/.test(filename);
    global.plugins = {};
    for (let filename of fs.readdirSync(pluginsPath).filter(pluginFilter)) {
        try {
            global.plugins[filename] = require(path.join(pluginsPath, filename));
        } catch (e) {
            conn.logger.error(e);
            delete global.plugins[filename];
        }
    }
    console.log(Object.keys(global.plugins));

    // Fungsi untuk me-reload plugin secara individu
    global.reload = (_event, file) => {
        if (pluginFilter(file)) {
            let pluginPath = path.join(pluginsPath, file);
            if (pluginPath in require.cache) {
                delete require.cache[pluginPath];
                if (fs.existsSync(pluginPath)) {
                    conn.logger.info(`re-require plugin '${file}'`);
                } else {
                    conn.logger.warn(`deleted plugin '${file}'`);
                    return delete global.plugins[file];
                }
            } else {
                conn.logger.info(`requiring new plugin '${file}'`);
            }
            let err = syntaxError(fs.readFileSync(pluginPath), file);
            if (err) {
                conn.logger.error(`syntax error while loading '${file}'\n${err}`);
            } else {
                try {
                    global.plugins[file] = require(pluginPath);
                } catch (e) {
                    conn.logger.error(e);
                } finally {
                    global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)));
                }
            }
        }
    };
    Object.freeze(global.reload);
    fs.watch(path.join(__dirname, "plugins"), global.reload);
    global.reloadHandler();

    // Memeriksa dependensi sistem (ffmpeg, etc.)
    async function checkSystemDependencies() {
        let TRIES = [
            spawn("ffmpeg"),
            spawn("ffprobe"),
            spawn("ffmpeg", ["-hide_banner", "-loglevel", "error", "-filter_complex", "color", "-frames:v", "1", "-f", "webp", "-"]),
            spawn("convert"),
            spawn("magick"),
            spawn("gm"),
            spawn("find", ["--version"]),
        ];

        let results = await Promise.all(TRIES.map(p => {
            return Promise.race([
                new Promise(resolve => {
                    p.on("close", code => resolve(code !== 127));
                }),
                new Promise(resolve => {
                    p.on("error", _ => resolve(false));
                })
            ]);
        }));

        let [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = results;
        console.log(results);
        const support = {
            ffmpeg,
            ffprobe,
            ffmpegWebp,
            convert,
            magick,
            gm,
            find
        };
        global.support = support;
        Object.freeze(global.support);

        if (!support.ffmpeg) conn.logger.warn("Harap install ffmpeg untuk mengirim video (pkg install ffmpeg)");
        if (support.ffmpeg && !support.ffmpegWebp) conn.logger.warn("Stiker mungkin tidak akan beranimasi tanpa libwebp di ffmpeg (--enable-ibwebp saat kompilasi ffmpeg)");
        if (!support.convert && !support.magick && !support.gm) conn.logger.warn("Stiker mungkin tidak berfungsi tanpa imagemagick jika libwebp di ffmpeg tidak terinstall (pkg install imagemagick)");
    }

    checkSystemDependencies().then(() => conn.logger.info("Tes Cepat Selesai")).catch(e => conn.logger.error(e));
}

startBot().catch(console.error);
