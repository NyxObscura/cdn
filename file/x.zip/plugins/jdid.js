
const fs = require('fs').promises;
const path = require('path');
const LOG_DIR = './broadcast_logs'
const BL_FILE = './broadcast_blacklist.json'

async function ensureBlacklistFile() {
  try { await fs.access(BL_FILE) } catch { await fs.writeFile(BL_FILE, '[]') }
}
async function loadBlacklist() {
  await ensureBlacklistFile()
  try {
    const raw = await fs.readFile(BL_FILE, 'utf8')
    const arr = JSON.parse(raw)
    return new Set(
      (Array.isArray(arr) ? arr : []).map(s => String(s || '').trim()).filter(Boolean)
    )
  } catch {
    await fs.writeFile(BL_FILE, '[]')
    return new Set()
  }
}

const delay = (ms) => new Promise(res => setTimeout(res, ms))

// === Parser durasi: "1jam30menit15detik", "2m", "90s", "45", "1h30m", dll ===
function parseDelayToSeconds(input) {
  if (!input) return null
  let s = String(input).trim().toLowerCase()
  // angka polos → detik
  if (/^\d+(?:[.,]\d+)?$/.test(s)) {
    return Math.round(parseFloat(s.replace(',', '.')))
  }
  // token num+unit (boleh tanpa spasi, boleh berantai)
  // dukungan unit: jam|j|h, menit|mnt|m, detik|dtk|s
  const re = /(\d+(?:[.,]\d+)?)(?:\s*)?(jam|j|h|menit|mnt|m|detik|dtk|s)/g
  let total = 0
  let matched = false
  for (let m; (m = re.exec(s)); ) {
    matched = true
    const val = parseFloat(m[1].replace(',', '.'))
    const unit = m[2]
    let mult = 1
    if (unit === 'jam' || unit === 'j' || unit === 'h') mult = 3600
    else if (unit === 'menit' || unit === 'mnt' || unit === 'm') mult = 60
    else if (unit === 'detik' || unit === 'dtk' || unit === 's') mult = 1
    total += val * mult
  }
  if (!matched) return null
  return Math.round(total)
}

function fmtDuration(sec) {
  sec = Math.max(0, Math.round(sec))
  const h = Math.floor(sec / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = sec % 60
  const parts = []
  if (h) parts.push(`${h} jam`)
  if (m) parts.push(`${m} menit`)
  if (s || parts.length === 0) parts.push(`${s} detik`)
  return parts.join(' ')
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const getGroups = await conn.groupFetchAllParticipating()
  const groups = Object.values(getGroups)
  const allIds = groups.map(g => g.id)

  // === Blacklist ===
  const blacklist = await loadBlacklist()
  const skipped = allIds.filter(id => blacklist.has(id))
  const targetIds = allIds.filter(id => !blacklist.has(id))

  // === Argumen siklus ===
  const raw = (text || '').trim()
  const parts = raw.split(/\s+/)

  const delayArg = parts[0]
  const delaySecParsed = parseDelayToSeconds(delayArg) // bisa null
  const numRepeat = Number(parts[1])
  const tailText = parts.slice(2).join(' ').trim()

  const quotedText = m.quoted && m.quoted.text ? m.quoted.text.trim() : ''
  const useCycles =
    Number.isFinite(delaySecParsed) && delaySecParsed >= 0 &&
    Number.isFinite(numRepeat) && numRepeat >= 1 &&
    (tailText || quotedText)

  const pesan = quotedText || (useCycles ? tailText : raw)

  if (!pesan) {
    throw `Format:\n` +
      `${usedPrefix + command} <delay> <ulang> <teks>\n` +
      `Contoh:\n` +
      `• ${usedPrefix + command} 8detik 10 halo\n` +
      `• ${usedPrefix + command} 2menit 5 *Promo baru*\n` +
      `• ${usedPrefix + command} 1jam 3 (balas pesan untuk pakai teks balasan)\n\n` +
      `Kamu juga bisa pakai angka detik biasa, mis. \`${usedPrefix + command} 30 2 halo\``
  }

  const totalCycles = useCycles ? numRepeat : 1
  const waitBetweenCyclesSec = useCycles ? delaySecParsed : 0

  // === Logging ===
  await fs.mkdir(LOG_DIR, { recursive: true })
  const logFile = path.join(
    LOG_DIR,
    `bcgc_${new Date().toISOString().replace(/[:.]/g, '-')}.json`
  )
  const log = async (obj) => {
    const row = JSON.stringify({ ts: new Date().toISOString(), ...obj }) + '\n'
    await fs.appendFile(logFile, row)
  }

  await log({
    type: 'start',
    from: m.sender,
    totalGroups: allIds.length,
    blacklisted: skipped.length,
    willSend: targetIds.length,
    totalCycles,
    waitBetweenCyclesSec
  })

  m.reply(
    `Broadcast dimulai.\n` +
    `Target: ${targetIds.length} grup (lewati ${skipped.length} di blacklist).\n` +
    `Siklus: ${totalCycles}×, jeda: ${fmtDuration(waitBetweenCyclesSec)}.\n` +
    `Log: ${logFile}`
  )

  if (skipped.length) {
    await log({ type: 'blacklist_skipped', groups: skipped })
  }

  // === Kirim per siklus ===
  for (let cycle = 1; cycle <= totalCycles; cycle++) {
    for (const gid of targetIds) {
      try {
        await conn.relayMessage(
          gid,
          { extendedTextMessage: { text: pesan, mentions: [m.sender] } },
          {}
        )
        await log({ type: 'sent', cycle, group: gid, ok: true })
      } catch (e) {
        await log({ type: 'sent', cycle, group: gid, ok: false, error: String(e) })
      }
      await delay(500) // throttle per pesan
    }

    if (cycle < totalCycles && waitBetweenCyclesSec > 0) {
      await log({ type: 'cycle_wait', cycle, waitSec: waitBetweenCyclesSec })
      await delay(waitBetweenCyclesSec * 1000)
    }
  }

  await log({ type: 'done' })
  m.reply(
    `Selesai broadcast ke ${targetIds.length} grup` +
    (totalCycles > 1 ? ` dalam ${totalCycles} siklus` : '') +
    `.`
  )
}

handler.help = [
  'bcgc <delay> <ulang> <teks> (atau balas pesan)',
  'Delay bisa: 8detik | 2menit | 1jam | gabungan (1jam30menit | 90s | 1h30m) atau angka detik'
]
handler.tags = ['owner']
handler.command = /^(jaser|gas|go)$/i
handler.owner = true

module.exports = handler;